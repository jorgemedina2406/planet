<?php
namespace App\Consolidated\Repositories;

use App\Consolidated\Entities\Consolidated;

/**
 * Class ConsolidatedRepo
 *
 * @package App\Consolidated\Repositories
 * @author  Jorge Medina
 */
class ConsolidatedRepo
{
    public function createConsolidated($data)
    {
        $consolidated = Consolidated::create($data);

        return $consolidated;
    }
    
    public function getAll($sort)
    {

        if( $sort === 'desc' ) {
            return Consolidated::all()->sortByDesc('des');
        }else{
            return Consolidated::all()->sortBy('des');
        }
    }

}
