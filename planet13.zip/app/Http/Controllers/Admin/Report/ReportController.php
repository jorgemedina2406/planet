<?php

namespace App\Http\Controllers\Admin\Report;

use App\User\Entities\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Filesystem\Filesystem;
use App\Http\Controllers\ApiController;

/* ENTITIES */
use App\Patent\Entities\Patent;
use App\Exporter\Entities\Exporter;
use App\Importer\Entities\Importer;
use App\Courier\Entities\Courier;
use App\Export\Entities\Export;
use App\Import\Entities\Import;
use App\Tax\Entities\Tax;

/* REPOSITORIES */
use App\Patent\Repositories\PatentRepo;

/* RESOURCE */
use App\Http\Resources\Patent as PatentResource;

/* LIB */
use PDF;
use Image;
use Carbon\Carbon;

use App\Exports\ReportImports;
use App\Exports\ReportExports;
use Maatwebsite\Excel\Facades\Excel;

class ReportController extends ApiController
{
    private $patentRepo;

    public function __construct( PatentRepo $patentRepo )
    {
        $this->patentRepo = $patentRepo;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // $data['Importer']
        // $data['exporters'] = Exporter::all();
        // $data['importers'] = Importer::all();
        // $data['couriers']  = Courier::all();

        $dataReport  = [];
        $dataType    = [];
        $dataStatus  = [];
        $dataCourier = [];
        $exporters   = Exporter::all();
        $importers   = Importer::all();
        $couriers    = Courier::all();   
        // $status      = $request->status;
        // $courier     = $request->courier;
        // $importer    = $request->importer;
        // $exporter    = $request->exporter;
        // $date_start  = $request->date;
        // $date_end    = $request->date_end;

        // $dateStart   = Carbon::parse($date_start);   
        // $dateEnd     = Carbon::parse($date_end);   
        
        $currentYear  = Carbon::now()->format('Y');
        $currentMonth = Carbon::now()->format('m');
        $endDayOfMonth = (int)Carbon::now()->endOfMonth()->format('d');
        $dayOfMonthProgram = Carbon::now()->startOfMonth();
        $dateNow = Carbon::now();

        // $diffNow = $dateNow->diffInDays($date_start);

        // \Log::debug('date_start',[$date_start]);

        \Log::debug('endayof',[$endDayOfMonth]);
        \Log::debug('dayOfMonthProgram',[$dayOfMonthProgram]);
        // \Log::debug('DAteStart',[$dateStart]);

        // if( $request->type == 1 ) {

            $query      = Import::all();
            $tax        = Tax::find(1);
            $type       = 1;

            $queryChart = collect();

            // \Log::debug('$dateNow->diffInDays($date_start)',[$dateNow->diffInDays($date_start)]);

            // if( $date_start != '' && !$date_end ){

                // if( $dateNow->diffInDays($date_start) > 31 ) {
                //     \Log::debug('assssss',['vvvvvvvvvv']);

                // }else{

                    for($i = 0; $i < $endDayOfMonth; $i++) {

                        \Log::debug('dayOfMonthProgramdayOfMonthProgram',[$dayOfMonthProgram->format('Y-m-d')]);
                        $data['date'] = $dayOfMonthProgram->format('Y-m-d');
                        $queryChartsEx = Export::charts($data)->get();
                        $queryCharts = Import::charts($data)->get();
                        // $data['date_start'] = $i;

                        $queryChart->push(array(
                            'y' => $dayOfMonthProgram->format('m-d'),
                            'a' => $queryCharts->count(),
                            'b' => $queryChartsEx->count()
                        ));

                        $dayOfMonthProgram->addDay(1);
                    }
                    // $queryChart = 
                    \Log::debug('zzzzzzzzzzz',['ssssssaaaa']);

                

            // $data['date'] = $date_start;
            $type = 2;
            \Log::debug('CCCCCCCCCXNNNNNNNNNNNNNNNNNNNNN',[$dayOfMonthProgram->subMonth(1)->format('Y-m-d')]);

            $data['date'] = $dayOfMonthProgram->subMonth(1)->format('Y-m-d');
            $query = Export::filters($data)->get();
        

        return view('admin.reports.reports', compact('type','query','queryChart','exporters','importers','couriers'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $data = $request->all();
        
        if( $request->type == 1 && $request->export == 1 ) {

            $query = Import::all();
            
            return (new ReportImports($data))->download('imports.xlsx');

        }elseif( $request->type == 2 && $request->export == 1 ){
            
            return (new ReportExports($data))->download('exports.xlsx');
        }


        $dataReport  = [];
        $dataType    = [];
        $dataStatus  = [];
        $dataCourier = [];
        $exporters   = Exporter::all();
        $importers   = Importer::all();
        $couriers    = Courier::all();   
        $status      = $request->status;
        $courier     = $request->courier;
        $importer    = $request->importer;
        $exporter    = $request->exporter;
        $mawb        = $request->mawb;
        $date_start  = $request->date;
        $date_end    = $request->date_end;

        $dateStart   = Carbon::parse($date_start);   
        $dateEnd     = Carbon::parse($date_end);   
        
        $currentYear  = Carbon::now()->format('Y');
        $currentMonth = Carbon::now()->format('m');
        $endDayOfMonth = (int)Carbon::now()->endOfMonth()->format('d');
        $dayOfMonthProgram = Carbon::now()->startOfMonth();
        $dateNow = Carbon::now();

        $diffNow = $dateNow->diffInDays($date_start);

        \Log::debug('date_start',[$date_start]);

        \Log::debug('endayof',[$endDayOfMonth]);
        \Log::debug('DAteStart',[$dateStart]);

        if( $request->type == 1 ) {

            $query      = Import::all();
            $tax        = Tax::find(1);
            $type       = 1;

            $queryChart = collect();

            \Log::debug('$dateNow->diffInDays($date_start)',[$dateNow->diffInDays($date_start)]);

            if( $date_start != '' && !$date_end ){

                if( $dateNow->diffInDays($date_start) > 31 ) {
                    \Log::debug('assssss',['vvvvvvvvvv']);

                }else{

                    for($i = 0; $i < $diffNow; $i++) {

                        \Log::debug('date start',[$dateStart->format('Y-m-d')]);
                        $data['date'] = $dateStart->format('Y-m-d');
                        $queryCharts = Import::charts($data)->get();
                        $queryChartsEx = Export::charts($data)->get();
                        // $data['date_start'] = $i;

                        $queryChart->push(array(
                            'y' => $dateStart->format('m-d'),
                            'a' => $queryCharts->count(),
                            'b' => $queryChartsEx->count()
                        ));

                        $dateStart->addDay(1);
                    }
                    // $queryChart = 
                    \Log::debug('zzzzzzzzzzz',['ssssssaaaa']);

                }

            }elseif( !$date_start && !$date_end ) {

                for($i = 0; $i < $endDayOfMonth; $i++) {

                    \Log::debug('dayOfMonthProgramdayOfMonthProgram',[$dayOfMonthProgram->format('Y-m-d')]);
                    $data['date'] = $dayOfMonthProgram->format('Y-m-d');
                    $queryChartsEx = Export::charts($data)->get();
                    $queryCharts = Import::charts($data)->get();
                    // $data['date_start'] = $i;

                    $queryChart->push(array(
                        'y' => $dayOfMonthProgram->format('m-d'),
                        'a' => $queryCharts->count(),
                        'b' => $queryChartsEx->count()
                    ));

                    $dayOfMonthProgram->addDay(1);
                }

            }elseif( $date_start && $date_end ) {

                \Log::debug('Date now',[$dateNow]);
                \Log::debug('Date end',[$dateEnd]);
                \Log::debug('Date START',[$date_start]);
                $diffEnd = $dateEnd->diffInDays($date_start);

                
                \Log::debug('Diff con date end',[$diffEnd]);

                if( Carbon::parse($date_end)->diffInDays($date_start) > 31 ) {
                    \Log::debug('kkkkkkkkk',['nnnnnnnn']);

                }else{

                    for($i = 0; $i < $diffEnd; $i++) {

                        \Log::debug('111 date start',[$dateStart->format('Y-m-d')]);
                        $data['date'] = $dateStart->format('Y-m-d');
                        $queryCharts = Import::charts($data)->get();
                        $queryChartsEx = Export::charts($data)->get();
                        // $data['date_start'] = $i;

                        $queryChart->push(array(
                            'y' => $dateStart->format('m-d'),
                            'a' => $queryCharts->count(),
                            'b' => $queryChartsEx->count()
                        ));

                        $dateStart->addDay(1);
                    }
                    \Log::debug('oooooooooo',['uuuuuuu']);

                }

            }

            $data['date'] = $date_start;
            $query = Import::filters($data)->get();
            
        }elseif( $request->type == 2 ){

            $query = Export::all();
            $tax   = Tax::find(1);
            $type = 2;

            $queryChart = collect();

            \Log::debug('$dateNow->diffInDays($date_start)',[$dateNow->diffInDays($date_start)]);

            if( $date_start != '' && !$date_end ){

                if( $dateNow->diffInDays($date_start) > 31 ) {
                    \Log::debug('assssss',['vvvvvvvvvv']);

                }else{

                    for($i = 0; $i < $diffNow; $i++) {

                        \Log::debug('date start',[$dateStart->format('Y-m-d')]);
                        $data['date'] = $dateStart->format('Y-m-d');
                        $queryCharts = Import::charts($data)->get();
                        $queryChartsEx = Export::charts($data)->get();
                        // $data['date_start'] = $i;

                        $queryChart->push(array(
                            'y' => $dateStart->format('m-d'),
                            'a' => $queryCharts->count(),
                            'b' => $queryChartsEx->count()
                        ));

                        $dateStart->addDay(1);
                    }
                    // $queryChart = 
                    \Log::debug('zzzzzzzzzzz',['ssssssaaaa']);

                }

            }elseif( !$date_start && !$date_end ) {

                for($i = 0; $i < $endDayOfMonth; $i++) {

                    \Log::debug('dayOfMonthProgramdayOfMonthProgram',[$dayOfMonthProgram->format('Y-m-d')]);
                    $data['date'] = $dayOfMonthProgram->format('Y-m-d');
                    $queryChartsEx = Export::charts($data)->get();
                    $queryCharts = Import::charts($data)->get();
                    // $data['date_start'] = $i;

                    $queryChart->push(array(
                        'y' => $dayOfMonthProgram->format('m-d'),
                        'a' => $queryCharts->count(),
                        'b' => $queryChartsEx->count()
                    ));

                    $dayOfMonthProgram->addDay(1);
                }

            }elseif( $date_start && $date_end ) {

                \Log::debug('Date now',[$dateNow]);
                \Log::debug('Date end',[$dateEnd]);
                \Log::debug('Date START',[$date_start]);
                $diffEnd = $dateEnd->diffInDays($date_start);

                
                \Log::debug('Diff con date end',[$diffEnd]);

                if( Carbon::parse($date_end)->diffInDays($date_start) > 31 ) {
                    \Log::debug('kkkkkkkkk',['nnnnnnnn']);

                }else{

                    for($i = 0; $i < $diffEnd; $i++) {

                        \Log::debug('111 date start',[$dateStart->format('Y-m-d')]);
                        $data['date'] = $dateStart->format('Y-m-d');
                        $queryCharts = Import::charts($data)->get();
                        $queryChartsEx = Export::charts($data)->get();
                        // $data['date_start'] = $i;

                        $queryChart->push(array(
                            'y' => $dateStart->format('m-d'),
                            'a' => $queryCharts->count(),
                            'b' => $queryChartsEx->count()
                        ));

                        $dateStart->addDay(1);
                    }
                    \Log::debug('oooooooooo',['uuuuuuu']);

                }

            }

            $data['date'] = $date_start;
            $query = Export::filters($data)->get();
        }

        \Log::debug('queryChart',[$queryChart]);

        return view('admin.reports.reports', compact('queryChart', 'status', 'importer', 'date_start', 'date_end', 'exporter', 'type', 'courier', 'couriers', 'importers', 'exporters', 'query') );

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function exportExcel(Request $request)
    {

        $data = $request->all();    

        \Log::debug('REUEST',[$data]);

        if( $request->type == 1 ) {

            $query = Import::all();
            
            return (new ReportImports($data))->download('imports.xlsx');

        }elseif( $request->type == 2 ){
            
            return (new ReportExports($data))->download('exports.xlsx');
        }

        
    }

}
