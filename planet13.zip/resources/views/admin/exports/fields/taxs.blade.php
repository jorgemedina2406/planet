<div class="col">
    <label class="form-control-label">IGE:</label>
    <input type="text" name="ige" class="form-control" placeholder="" value="{{ $tax->ige }}" readonly>
</div>
<div class="col">
    <label class="form-control-label">DTA:</label>
    <input type="text" name="dta" class="form-control" placeholder="" value="{{ $tax->dta }}" readonly>
</div>
<div class="col">
    <label class="form-control-label">PRV:</label>
    <input type="text" name="prv" class="form-control" placeholder="" value="{{ $tax->prv }}" readonly>
</div>
<div class="col">
    <label class="form-control-label">CNT:</label>
    <input type="text" name="cnt" class="form-control" placeholder="" value="{{ $tax->cnt }}" readonly>
</div>