<div class="kt-footer  kt-grid__item kt-grid kt-grid--desktop kt-grid--ver-desktop" id="kt_footer">
    <div class="kt-container  kt-container--fluid ">
        <div class="kt-footer__copyright">
            {{ date('Y') }}&nbsp;&copy;&nbsp;<a href="http://www.planetlogistic.com.mx" target="_blank" class="kt-link">Planet Logistic  </a> &nbsp;S.A. DE C.V. Todos los derechos reservados. Desarrollado por
            <a href="http://www.planetlogistic.com.mx" target="_blank" class="kt-link">   
                &nbsp;dosbytes.com.mx</a>
        </div>
        <div class="kt-footer__menu">
            <a href="http://dosbytes..com.mx" target="_blank" class="kt-footer__menu-link kt-link">Hecho con <i class="fa fa-heart text-danger"></i> para Mexico</a>
        </div>
    </div>
</div>