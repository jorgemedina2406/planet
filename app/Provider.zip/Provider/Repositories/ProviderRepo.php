<?php
namespace App\Provider\Repositories;

use App\Provider\Entities\Provider;

/**
 * Class ProviderRepo
 *
 * @package App\Provider\Repositories
 * @author  Jorge Medina
 */
class ProviderRepo
{
    public function createProvider($data)
    {
        return Provider::create($data);
    }

        
    public function getAll()
    {
        return Provider::all()->sortByDesc('created_at');
    }

}
